FPS Booster X - V3
Package used (sanitized): com.game.fpsbooster

How to open:
1. Open Android Studio.
2. Import project from: /path/to/project (this folder).
3. Grant overlay permission on device for overlay features.
4. Build and run on a real device (recommended minSdk 24).

Notes:
- The project is a functional MVP. Some system-level optimizations (ndc, CPU/GPU tweaks)
  use shell commands that may require device support and permissions.
- If overlay doesn't appear, ensure 'Display over other apps' permission is granted.
